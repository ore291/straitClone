<?php

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname = "strait"; /* Database name */

$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

$data = json_decode(file_get_contents("php://input"));

$request = $data->request;

echo $data;

// Fetch All records
if($request == 1){
  $userData = mysqli_query($con,"select * from donations order by id desc");

  $response = array();
  while($row = mysqli_fetch_assoc($userData)){
    $response[] = $row;
  }

  echo json_encode($response);
  exit;
}

// Add record
if($request == 2){
  $firstname = $data->firstname;
  $lastname = $data->lastname;
  $amount = $data ->amount;
  $email = $data->email;

  $userData = mysqli_query($con,"SELECT * FROM donations WHERE firstname='".$firstname."'");
  if(mysqli_num_rows($userData) == 0){
    mysqli_query($con,"INSERT INTO donations(firstname,lastname,email,amount) VALUES('".$firstname."','".$lastname."','".$email."',,'".$amount."')");
    echo "Insert successfully";
  }else{
    echo "Username already exists.";
  }

  exit;
}

// Update record
if($request == 3){
  $id = $data->id;
  $name = $data->name;
  $email = $data->email;

  mysqli_query($con,"UPDATE users SET name='".$name."',email='".$email."' WHERE id=".$id);
 
  echo "Update successfully";
  exit;
}

// Delete record
if($request == 4){
  $id = $data->id;

  mysqli_query($con,"DELETE FROM users WHERE id=".$id);

  echo "Delete successfully";
  exit;
}

?>